import { NextRequest, NextResponse } from 'next/server';

async function digest(value: string) {
  const bytes = new TextEncoder().encode(value);
  const hash = await crypto.subtle.digest('SHA-256', bytes);
  return Array.from(new Uint8Array(hash))
    .map((byte) => byte.toString(16).padStart(2, '0'))
    .join('');
}

export async function middleware(req: NextRequest) {
  const password = process.env.ARIDON_ACCESS_PASSWORD?.trim();
  if (!password) return NextResponse.next();

  const path = req.nextUrl.pathname;
  if (
    path === '/login' ||
    path === '/api/auth/login' ||
    path.startsWith('/_next/') ||
    path === '/favicon.ico'
  ) {
    return NextResponse.next();
  }

  const secret = process.env.ARIDON_SESSION_SECRET?.trim() || 'aridon-session';
  const expected = await digest(`${password}:${secret}`);
  const actual = req.cookies.get('aridon_session')?.value;
  if (actual === expected) return NextResponse.next();

  if (path.startsWith('/api/')) {
    return NextResponse.json({ error: 'Authentication required.' }, { status: 401 });
  }

  const loginUrl = req.nextUrl.clone();
  loginUrl.pathname = '/login';
  loginUrl.searchParams.set('next', path);
  return NextResponse.redirect(loginUrl);
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|.*\\.(?:png|jpg|jpeg|gif|svg|webp)$).*)']
};
