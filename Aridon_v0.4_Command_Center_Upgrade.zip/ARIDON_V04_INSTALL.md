# Install the Aridon v0.4 Command Center Upgrade

This upgrade overlays the existing `jimrusk/aridon-app` repository. It does not require new npm packages.

## Files added or replaced

- Private password login and session middleware
- Founder dashboard and executive chat
- Communications Center with review-before-send email and SMS
- Searchable contacts directory with 40 public/business research contacts
- CRM, projects, tasks, and Knowledge Vault CRUD improvements
- Supabase contacts and communications tables
- Resend and Twilio provider routes
- Private owner-contact environment settings

## Apply to the repository

Extract this archive into the root of the existing `aridon-app` project and allow it to replace matching files. Commit the changes to GitHub, then redeploy the Vercel project.

## Supabase

Run `supabase-schema.sql` in the Supabase SQL Editor. The script uses `create table if not exists` and can be run more than once.

## Vercel environment variables

Copy the variable names from `.env.example` into Vercel Project Settings. At minimum, configure:

- `ARIDON_ACCESS_PASSWORD`
- `ARIDON_SESSION_SECRET`
- `OPENAI_API_KEY`
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- `SUPABASE_SERVICE_ROLE_KEY`

For private “Message Jim” actions, add `ARIDON_OWNER_EMAIL` and `ARIDON_OWNER_PHONE` in Vercel. Do not commit those values to GitHub.

For outbound email, add a Resend key and a verified sender in `ARIDON_FROM_EMAIL`. For SMS, add the Twilio variables.

## Contact privacy

The built-in directory contains public agency, university, utility, Tribal-government, and manufacturing routing contacts from Aridon research packages. Private relationship contacts from Jim's inbox are deliberately not hardcoded into this public repository. Add those through the protected Contacts screen after Supabase is active.
