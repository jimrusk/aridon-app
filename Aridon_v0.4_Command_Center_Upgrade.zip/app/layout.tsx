import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Aridon Command Center',
  description: 'Aridon executive operations, contacts, communications, CRM, projects, tasks, and Knowledge Vault.',
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
