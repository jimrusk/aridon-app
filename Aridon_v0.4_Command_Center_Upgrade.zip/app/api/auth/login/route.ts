import { createHash, timingSafeEqual } from 'crypto';
import { NextRequest, NextResponse } from 'next/server';
import { cleanText, jsonError } from '../../../../lib/routeHelpers';

function sessionToken(password: string) {
  const secret = process.env.ARIDON_SESSION_SECRET?.trim() || 'aridon-session';
  return createHash('sha256').update(`${password}:${secret}`).digest('hex');
}

function safeEqual(left: string, right: string) {
  const a = Buffer.from(left);
  const b = Buffer.from(right);
  return a.length === b.length && timingSafeEqual(a, b);
}

export async function POST(req: NextRequest) {
  const configured = process.env.ARIDON_ACCESS_PASSWORD?.trim();
  if (!configured) return jsonError('ARIDON_ACCESS_PASSWORD is not configured.', 503);

  const body = (await req.json()) as { password?: string };
  const supplied = cleanText(body.password, 500);
  if (!safeEqual(supplied, configured)) return jsonError('Incorrect password.', 401);

  const response = NextResponse.json({ ok: true });
  response.cookies.set('aridon_session', sessionToken(configured), {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'strict',
    path: '/',
    maxAge: 60 * 60 * 24 * 14
  });
  return response;
}
