import { NextRequest, NextResponse } from 'next/server';
import { getServerClient } from '../../../lib/supabase';
import { optionalString, requiredString } from '../../../lib/serverAuth';

function payload(body: Record<string, unknown>) {
  return {
    name: requiredString(body.name, 'Name', 160),
    company: optionalString(body.company, 200),
    email: optionalString(body.email, 320),
    notes: optionalString(body.notes, 3000),
    status: optionalString(body.status, 40) || 'new',
  };
}

export async function GET() {
  try {
    const db = getServerClient();
    const { data, error } = await db.from('leads').select('*').order('created_at', { ascending: false });
    if (error) throw error;
    return NextResponse.json(data || []);
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Unable to load leads.' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as Record<string, unknown>;
    const db = getServerClient();
    const { data, error } = await db.from('leads').insert(payload(body)).select().single();
    if (error) throw error;
    return NextResponse.json(data, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Unable to add lead.' }, { status: 400 });
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const body = (await req.json()) as Record<string, unknown>;
    const id = requiredString(body.id, 'Lead id', 100);
    const db = getServerClient();
    const { data, error } = await db.from('leads').update(payload(body)).eq('id', id).select().single();
    if (error) throw error;
    return NextResponse.json(data);
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Unable to update lead.' }, { status: 400 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const body = (await req.json()) as Record<string, unknown>;
    const id = requiredString(body.id, 'Lead id', 100);
    const db = getServerClient();
    const { error } = await db.from('leads').delete().eq('id', id);
    if (error) throw error;
    return NextResponse.json({ ok: true });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Unable to delete lead.' }, { status: 400 });
  }
}
