import { NextRequest, NextResponse } from 'next/server';
import OpenAI from 'openai';
import { buildSystemPrompt } from '../../../lib/systemPrompt';

type ChatMessage = { role: 'user' | 'assistant'; content: string };

export async function POST(req: NextRequest) {
  try {
    const data = (await req.json()) as {
      messages?: ChatMessage[];
      executive?: string;
    };

    if (!process.env.ARIDON_ACCESS_PASSWORD?.trim()) {
      return NextResponse.json({ reply: 'Set ARIDON_ACCESS_PASSWORD in Vercel before enabling live executive chat.' }, { status: 503 });
    }

    if (!process.env.OPENAI_API_KEY) {
      return NextResponse.json({
        reply: 'Heather is in demo mode. Add OPENAI_API_KEY in Vercel Environment Variables to activate live executive responses.',
      });
    }

    const messages = (data.messages || [])
      .filter((message) => message && (message.role === 'user' || message.role === 'assistant'))
      .slice(-30)
      .map((message) => ({
        role: message.role,
        content: String(message.content || '').slice(0, 12000),
      }));

    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const completion = await client.chat.completions.create({
      model: process.env.OPENAI_MODEL || 'gpt-4o-mini',
      messages: [
        { role: 'system', content: buildSystemPrompt(data.executive || 'Heather') },
        ...messages,
      ],
      temperature: 0.55,
    });

    return NextResponse.json({
      reply: completion.choices[0]?.message?.content || 'I am online, but I did not receive a clear response.',
    });
  } catch (error) {
    return NextResponse.json(
      { reply: `The executive team hit an error: ${error instanceof Error ? error.message : 'Unknown error'}` },
      { status: 500 },
    );
  }
}
