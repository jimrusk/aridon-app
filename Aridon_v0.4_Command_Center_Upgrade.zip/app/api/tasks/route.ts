import { NextRequest, NextResponse } from 'next/server';
import { getServerClient } from '../../../lib/supabase';
import { optionalString, requiredString } from '../../../lib/serverAuth';

function payload(body: Record<string, unknown>) {
  return {
    title: requiredString(body.title, 'Task title', 240),
    assigned_to: optionalString(body.assigned_to, 160),
    priority: optionalString(body.priority, 40) || 'medium',
    status: optionalString(body.status, 40) || 'open',
  };
}

export async function GET() {
  try {
    const db = getServerClient();
    const { data, error } = await db.from('tasks').select('*').order('created_at', { ascending: false });
    if (error) throw error;
    return NextResponse.json(data || []);
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Unable to load tasks.' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as Record<string, unknown>;
    const db = getServerClient();
    const { data, error } = await db.from('tasks').insert(payload(body)).select().single();
    if (error) throw error;
    return NextResponse.json(data, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Unable to add task.' }, { status: 400 });
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const body = (await req.json()) as Record<string, unknown>;
    const id = requiredString(body.id, 'Task id', 100);
    const db = getServerClient();
    const { data, error } = await db.from('tasks').update(payload(body)).eq('id', id).select().single();
    if (error) throw error;
    return NextResponse.json(data);
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Unable to update task.' }, { status: 400 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const body = (await req.json()) as Record<string, unknown>;
    const id = requiredString(body.id, 'Task id', 100);
    const db = getServerClient();
    const { error } = await db.from('tasks').delete().eq('id', id);
    if (error) throw error;
    return NextResponse.json({ ok: true });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Unable to delete task.' }, { status: 400 });
  }
}
