import { NextRequest, NextResponse } from 'next/server';

export async function POST(req: NextRequest) {
  const data = (await req.json()) as { companyName?: string; services?: string; customers?: string };
  const companyName = data.companyName?.trim() || 'Your Company';
  const services = data.services?.trim() || 'your core services';
  const customers = data.customers?.trim() || 'your customers';

  return NextResponse.json({
    companyName,
    recommendedExecutives: ['Heather', 'Ethos', 'Atlas', 'Eva', 'Scout', 'Ledger', 'Oracle'],
    firstModules: ['Dashboard', 'Executive Chat', 'Communications', 'Contacts', 'CRM', 'Projects', 'Tasks', 'Knowledge Vault'],
    setupSummary: `Aridon will configure an AI executive operating system for ${companyName}, serving ${customers}, with workflows built around ${services}.`,
    nextSteps: [
      'Confirm the private access key and owner contact settings',
      'Load public research contacts and add private relationship contacts in Supabase',
      'Connect a verified email domain and SMS number',
      'Add the first active projects, leads, and task owners',
      'Upload approved business documents to the Knowledge Vault',
      'Start a daily executive review using verified operating data',
    ],
  });
}
