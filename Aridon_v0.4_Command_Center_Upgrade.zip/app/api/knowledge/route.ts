import { NextRequest, NextResponse } from 'next/server';
import { getServerClient } from '../../../lib/supabase';
import { optionalString, requiredString } from '../../../lib/serverAuth';

function payload(body: Record<string, unknown>) {
  return {
    title: requiredString(body.title, 'Document title', 240),
    category: optionalString(body.category, 120),
    content: optionalString(body.content, 20000),
  };
}

export async function GET() {
  try {
    const db = getServerClient();
    const { data, error } = await db.from('knowledge_vault').select('*').order('created_at', { ascending: false });
    if (error) throw error;
    return NextResponse.json(data || []);
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Unable to load Knowledge Vault.' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as Record<string, unknown>;
    const db = getServerClient();
    const { data, error } = await db.from('knowledge_vault').insert(payload(body)).select().single();
    if (error) throw error;
    return NextResponse.json(data, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Unable to add document.' }, { status: 400 });
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const body = (await req.json()) as Record<string, unknown>;
    const id = requiredString(body.id, 'Document id', 100);
    const db = getServerClient();
    const { data, error } = await db.from('knowledge_vault').update(payload(body)).eq('id', id).select().single();
    if (error) throw error;
    return NextResponse.json(data);
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Unable to update document.' }, { status: 400 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const body = (await req.json()) as Record<string, unknown>;
    const id = requiredString(body.id, 'Document id', 100);
    const db = getServerClient();
    const { error } = await db.from('knowledge_vault').delete().eq('id', id);
    if (error) throw error;
    return NextResponse.json({ ok: true });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Unable to delete document.' }, { status: 400 });
  }
}
