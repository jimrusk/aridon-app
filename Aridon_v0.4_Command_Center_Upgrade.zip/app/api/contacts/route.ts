import { NextRequest, NextResponse } from 'next/server';
import { randomUUID } from 'crypto';
import { getServerClient } from '../../../lib/supabase';
import { seedContacts, type ContactRecord } from '../../../lib/seedContacts';
import { optionalString, requiredString } from '../../../lib/serverAuth';

function ownerContact(): ContactRecord | null {
  const email = process.env.ARIDON_OWNER_EMAIL?.trim();
  const phone = process.env.ARIDON_OWNER_PHONE?.trim();
  if (!email && !phone) return null;
  return {
    external_key: 'owner-jim-rusk',
    name: process.env.ARIDON_OWNER_NAME?.trim() || 'Jim Rusk',
    organization: 'Aridon / Iron Grid Electric & Water',
    title: 'Founder',
    email,
    phone,
    state: 'NM',
    category: 'Aridon',
    notes: 'Private owner contact loaded from Vercel environment variables.',
    verification: 'verified',
    source: 'Private environment settings',
  };
}

function fallbackContacts(): ContactRecord[] {
  const owner = ownerContact();
  return [...(owner ? [owner] : []), ...seedContacts].map((contact) => ({
    ...contact,
    id: `seed:${contact.external_key}`,
    is_seed: true,
  }));
}

function contactPayload(body: Record<string, unknown>) {
  return {
    external_key:
      optionalString(body.external_key, 160) ||
      `custom-${randomUUID()}`,
    name: requiredString(body.name, 'Name', 160),
    organization: requiredString(body.organization, 'Organization', 200),
    title: optionalString(body.title, 200),
    email: optionalString(body.email, 320),
    phone: optionalString(body.phone, 60),
    city: optionalString(body.city, 120),
    state: optionalString(body.state, 40),
    category: optionalString(body.category, 100) || 'Other',
    notes: optionalString(body.notes, 3000),
    verification: optionalString(body.verification, 40) || 'research-lead',
    source: optionalString(body.source, 300) || 'Added in Aridon',
  };
}

export async function GET() {
  const fallback = fallbackContacts();
  try {
    const db = getServerClient();
    const { data, error } = await db.from('contacts').select('*').order('organization', { ascending: true });
    if (error) {
      return NextResponse.json({ contacts: fallback, source: 'seed', warning: error.message });
    }

    const merged = new Map<string, ContactRecord>();
    fallback.forEach((contact) => merged.set(contact.external_key, contact));
    (data || []).forEach((contact: ContactRecord) => {
      merged.set(contact.external_key || contact.id || randomUUID(), { ...contact, is_seed: false });
    });

    return NextResponse.json({ contacts: Array.from(merged.values()), source: 'database+seed' });
  } catch (error) {
    return NextResponse.json({
      contacts: fallback,
      source: 'seed',
      warning: error instanceof Error ? error.message : 'Contacts database is unavailable.',
    });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as Record<string, unknown>;
    const payload = contactPayload(body);
    const db = getServerClient();
    const { data, error } = await db.from('contacts').insert(payload).select().single();
    if (error) throw error;
    return NextResponse.json(data, { status: 201 });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Unable to add contact.' },
      { status: 400 },
    );
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const body = (await req.json()) as Record<string, unknown>;
    const id = requiredString(body.id, 'Contact id', 200);
    const payload = contactPayload(body);
    const db = getServerClient();

    if (id.startsWith('seed:')) {
      const { data, error } = await db
        .from('contacts')
        .upsert(payload, { onConflict: 'external_key' })
        .select()
        .single();
      if (error) throw error;
      return NextResponse.json(data);
    }

    const { data, error } = await db.from('contacts').update(payload).eq('id', id).select().single();
    if (error) throw error;
    return NextResponse.json(data);
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Unable to update contact.' },
      { status: 400 },
    );
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const body = (await req.json()) as Record<string, unknown>;
    const id = requiredString(body.id, 'Contact id', 200);
    if (id.startsWith('seed:')) {
      return NextResponse.json({ error: 'Built-in research contacts cannot be deleted.' }, { status: 400 });
    }
    const db = getServerClient();
    const { error } = await db.from('contacts').delete().eq('id', id);
    if (error) throw error;
    return NextResponse.json({ ok: true });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Unable to delete contact.' },
      { status: 400 },
    );
  }
}
