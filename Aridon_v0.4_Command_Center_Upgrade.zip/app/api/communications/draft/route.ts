import { NextRequest, NextResponse } from 'next/server';
import OpenAI from 'openai';
import { buildSystemPrompt } from '../../../../lib/systemPrompt';
import { optionalString, requiredString } from '../../../../lib/serverAuth';

export async function POST(req: NextRequest) {
  try {
    const data = (await req.json()) as Record<string, unknown>;
    if (!process.env.ARIDON_ACCESS_PASSWORD?.trim()) {
      return NextResponse.json({ error: 'Set ARIDON_ACCESS_PASSWORD in Vercel before enabling executive drafting.' }, { status: 503 });
    }
    if (!process.env.OPENAI_API_KEY) {
      return NextResponse.json({ error: 'Add OPENAI_API_KEY in Vercel to create executive drafts.' }, { status: 503 });
    }

    const executive = optionalString(data.executive, 80) || 'Heather';
    const channel = requiredString(data.channel, 'Channel', 20);
    const goal = requiredString(data.goal, 'Message goal', 3000);
    const recipientName = optionalString(data.recipientName, 200) || 'the recipient';
    const organization = optionalString(data.organization, 240) || '';
    const notes = optionalString(data.notes, 3000) || '';

    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const completion = await client.chat.completions.create({
      model: process.env.OPENAI_MODEL || 'gpt-4o-mini',
      temperature: 0.45,
      response_format: { type: 'json_object' },
      messages: [
        { role: 'system', content: buildSystemPrompt(executive) },
        {
          role: 'user',
          content: `Draft a ${channel} for Jim Rusk to send through Aridon.\nRecipient: ${recipientName}${organization ? ` at ${organization}` : ''}.\nGoal: ${goal}\nRelevant contact notes: ${notes || 'None provided.'}\nReturn valid JSON with exactly two string fields: subject and body. For SMS, subject must be an empty string. Do not claim that a meeting, funding award, engineering result, or product performance is confirmed unless the goal explicitly says it is. Keep the message practical, credible, and ready for Jim to review.`,
        },
      ],
    });

    const raw = completion.choices[0]?.message?.content || '{}';
    const parsed = JSON.parse(raw) as { subject?: string; body?: string };
    return NextResponse.json({ subject: parsed.subject || '', body: parsed.body || '' });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Unable to create draft.' },
      { status: 400 },
    );
  }
}
