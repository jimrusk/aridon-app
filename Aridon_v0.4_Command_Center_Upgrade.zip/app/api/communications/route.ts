import { NextRequest, NextResponse } from 'next/server';
import { getServerClient } from '../../../lib/supabase';
import { optionalString, requiredString } from '../../../lib/serverAuth';

type LogInput = {
  channel: string;
  recipient_name: string | null;
  recipient: string;
  subject: string | null;
  body: string;
  status: string;
  provider_id?: string | null;
  error?: string | null;
};

async function logCommunication(input: LogInput) {
  try {
    const db = getServerClient();
    await db.from('communications').insert(input);
  } catch {
    // Sending should not fail merely because the optional audit table is unavailable.
  }
}

async function sendEmail(to: string, subject: string, body: string) {
  const apiKey = process.env.RESEND_API_KEY;
  const from = process.env.ARIDON_FROM_EMAIL;
  if (!apiKey || !from) {
    throw new Error('Email is not configured. Add RESEND_API_KEY and ARIDON_FROM_EMAIL in Vercel.');
  }

  const response = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      from,
      to: [to],
      subject,
      text: body,
      reply_to: process.env.ARIDON_OWNER_EMAIL || undefined,
    }),
  });

  const data = (await response.json().catch(() => ({}))) as { id?: string; message?: string; error?: { message?: string } };
  if (!response.ok) {
    throw new Error(data.error?.message || data.message || 'Email provider rejected the message.');
  }
  return data.id || null;
}

async function sendSms(to: string, body: string) {
  const accountSid = process.env.TWILIO_ACCOUNT_SID;
  const authToken = process.env.TWILIO_AUTH_TOKEN;
  const from = process.env.TWILIO_FROM_NUMBER;
  if (!accountSid || !authToken || !from) {
    throw new Error('SMS is not configured. Add TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, and TWILIO_FROM_NUMBER in Vercel.');
  }

  const form = new URLSearchParams({ To: to, From: from, Body: body });
  const response = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`, {
    method: 'POST',
    headers: {
      Authorization: `Basic ${Buffer.from(`${accountSid}:${authToken}`).toString('base64')}`,
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: form.toString(),
  });

  const data = (await response.json().catch(() => ({}))) as { sid?: string; message?: string };
  if (!response.ok) throw new Error(data.message || 'SMS provider rejected the message.');
  return data.sid || null;
}

export async function GET() {
  try {
    const db = getServerClient();
    const { data, error } = await db
      .from('communications')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(25);
    if (error) throw error;
    return NextResponse.json(data || []);
  } catch {
    return NextResponse.json([]);
  }
}

export async function POST(req: NextRequest) {
  let logInput: LogInput | null = null;
  try {
    const data = (await req.json()) as Record<string, unknown>;
    if (!process.env.ARIDON_ACCESS_PASSWORD?.trim()) {
      return NextResponse.json({ error: 'Set ARIDON_ACCESS_PASSWORD in Vercel before enabling outbound messages.' }, { status: 503 });
    }

    const channel = requiredString(data.channel, 'Channel', 20).toLowerCase();
    if (channel !== 'email' && channel !== 'sms') throw new Error('Channel must be email or sms.');

    const recipient = requiredString(data.to, 'Recipient', 320);
    const recipientName = optionalString(data.recipientName, 200);
    const body = requiredString(data.body, 'Message', channel === 'sms' ? 1500 : 20000);
    const subject = channel === 'email' ? requiredString(data.subject, 'Subject', 240) : null;

    logInput = {
      channel,
      recipient_name: recipientName,
      recipient,
      subject,
      body,
      status: 'sending',
    };

    const providerId = channel === 'email'
      ? await sendEmail(recipient, subject || 'Message from Aridon', body)
      : await sendSms(recipient, body);

    await logCommunication({ ...logInput, status: 'sent', provider_id: providerId });
    return NextResponse.json({ ok: true, status: 'sent', providerId }, { status: 201 });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unable to send message.';
    if (logInput) await logCommunication({ ...logInput, status: 'failed', error: message });
    return NextResponse.json({ error: message }, { status: 400 });
  }
}
