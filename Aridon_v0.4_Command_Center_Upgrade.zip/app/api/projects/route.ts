import { NextRequest, NextResponse } from 'next/server';
import { getServerClient } from '../../../lib/supabase';
import { optionalString, requiredString } from '../../../lib/serverAuth';

function payload(body: Record<string, unknown>) {
  return {
    name: requiredString(body.name, 'Project name', 200),
    description: optionalString(body.description, 3000),
    executive: optionalString(body.executive, 100) || 'Heather',
    status: optionalString(body.status, 40) || 'planning',
  };
}

export async function GET() {
  try {
    const db = getServerClient();
    const { data, error } = await db.from('projects').select('*').order('created_at', { ascending: false });
    if (error) throw error;
    return NextResponse.json(data || []);
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Unable to load projects.' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as Record<string, unknown>;
    const db = getServerClient();
    const { data, error } = await db.from('projects').insert(payload(body)).select().single();
    if (error) throw error;
    return NextResponse.json(data, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Unable to add project.' }, { status: 400 });
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const body = (await req.json()) as Record<string, unknown>;
    const id = requiredString(body.id, 'Project id', 100);
    const db = getServerClient();
    const { data, error } = await db.from('projects').update(payload(body)).eq('id', id).select().single();
    if (error) throw error;
    return NextResponse.json(data);
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Unable to update project.' }, { status: 400 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const body = (await req.json()) as Record<string, unknown>;
    const id = requiredString(body.id, 'Project id', 100);
    const db = getServerClient();
    const { error } = await db.from('projects').delete().eq('id', id);
    if (error) throw error;
    return NextResponse.json({ ok: true });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Unable to delete project.' }, { status: 400 });
  }
}
