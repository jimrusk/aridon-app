'use client';

import { useEffect, useMemo, useState, type CSSProperties } from 'react';
import { executives } from '../lib/executives';

type Msg = { role: 'user' | 'assistant'; content: string };
type Lead = { id: string; name: string; company: string | null; status: string; notes: string | null; email: string | null };
type Project = { id: string; name: string; status: string; description: string | null; executive: string | null };
type Task = { id: string; title: string; status: string; priority: string; assigned_to: string | null };
type KnowledgeItem = { id: string; title: string; content: string | null; category: string | null };
type Contact = {
  id: string;
  external_key: string;
  name: string;
  organization: string;
  title?: string | null;
  email?: string | null;
  phone?: string | null;
  city?: string | null;
  state?: string | null;
  category: string;
  notes?: string | null;
  verification: string;
  source?: string | null;
  is_seed?: boolean;
};
type CommunicationLog = {
  id: string;
  channel: string;
  recipient_name: string | null;
  recipient: string;
  subject: string | null;
  body: string;
  status: string;
  created_at: string;
};
type BuilderPlan = {
  setupSummary: string;
  firstModules: string[];
  nextSteps: string[];
};
type ContactsResponse = { contacts: Contact[]; source: string; warning?: string };

type TabName =
  | 'Dashboard'
  | 'Executive Chat'
  | 'Communications'
  | 'Contacts'
  | 'CRM'
  | 'Projects'
  | 'Tasks'
  | 'Knowledge Vault'
  | 'Builder Mode'
  | 'Executive Team';

const tabs: TabName[] = [
  'Dashboard',
  'Executive Chat',
  'Communications',
  'Contacts',
  'CRM',
  'Projects',
  'Tasks',
  'Knowledge Vault',
  'Builder Mode',
  'Executive Team',
];

const statusColor = (status: string) => {
  const value = status.toLowerCase();
  if (['active', 'open', 'new', 'qualified', 'sent', 'verified'].includes(value)) return '#42d392';
  if (['complete', 'closed', 'done'].includes(value)) return '#65b7ff';
  if (['failed', 'high'].includes(value)) return '#ff6b6b';
  return '#ff9d4d';
};

async function api<T>(url: string, options?: RequestInit): Promise<T> {
  const response = await fetch(url, options);
  const data = (await response.json().catch(() => ({}))) as Record<string, unknown>;
  if (!response.ok) {
    throw new Error(String(data.error || data.reply || `Request failed (${response.status})`));
  }
  return data as T;
}

function nextValue(current: string, values: string[]) {
  const index = values.indexOf(current);
  return values[(index + 1) % values.length];
}

export default function Home() {
  const [tab, setTab] = useState<TabName>('Dashboard');
  const [executive, setExecutive] = useState('Heather');
  const [messages, setMessages] = useState<Msg[]>([
    { role: 'assistant', content: 'Welcome to Aridon. Your executive team is online. What are we moving forward today?' },
  ]);
  const [chatInput, setChatInput] = useState('');
  const [chatBusy, setChatBusy] = useState(false);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');
  const [dataWarning, setDataWarning] = useState('');

  const [leads, setLeads] = useState<Lead[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [knowledge, setKnowledge] = useState<KnowledgeItem[]>([]);
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [contactSource, setContactSource] = useState('seed');
  const [communicationLogs, setCommunicationLogs] = useState<CommunicationLog[]>([]);

  const [newLead, setNewLead] = useState({ name: '', company: '', email: '', notes: '', status: 'new' });
  const [newProject, setNewProject] = useState({ name: '', description: '', executive: 'Heather', status: 'planning' });
  const [newTask, setNewTask] = useState({ title: '', assigned_to: '', priority: 'medium', status: 'open' });
  const [newKnowledge, setNewKnowledge] = useState({ title: '', category: '', content: '' });
  const [newContact, setNewContact] = useState({
    name: '', organization: '', title: '', email: '', phone: '', city: '', state: 'NM', category: 'Other', notes: '', verification: 'research-lead',
  });

  const [contactSearch, setContactSearch] = useState('');
  const [contactCategory, setContactCategory] = useState('All');

  const [communication, setCommunication] = useState({
    contactId: '',
    channel: 'email',
    to: '',
    subject: '',
    body: '',
    goal: '',
    executive: 'Heather',
  });
  const [communicationBusy, setCommunicationBusy] = useState<'draft' | 'send' | ''>('');

  const [builder, setBuilder] = useState({
    companyName: 'Aridon',
    services: 'AWG-1000 atmospheric water, resilient power integration, AI operations, communications, CRM, and infrastructure project coordination',
    customers: 'Tribal governments, rural communities, utilities, public agencies, manufacturers, universities, data centers, and critical facilities',
  });
  const [builderPlan, setBuilderPlan] = useState<BuilderPlan | null>(null);

  useEffect(() => {
    void loadAll();
  }, []);

  async function loadAll() {
    const warnings: string[] = [];
    await Promise.all([
      api<Lead[]>('/api/crm').then(setLeads).catch((reason: Error) => warnings.push(`CRM: ${reason.message}`)),
      api<Project[]>('/api/projects').then(setProjects).catch((reason: Error) => warnings.push(`Projects: ${reason.message}`)),
      api<Task[]>('/api/tasks').then(setTasks).catch((reason: Error) => warnings.push(`Tasks: ${reason.message}`)),
      api<KnowledgeItem[]>('/api/knowledge').then(setKnowledge).catch((reason: Error) => warnings.push(`Vault: ${reason.message}`)),
      api<ContactsResponse>('/api/contacts')
        .then((result) => {
          setContacts(result.contacts);
          setContactSource(result.source);
          if (result.warning) warnings.push(`Contacts: ${result.warning}`);
        })
        .catch((reason: Error) => warnings.push(`Contacts: ${reason.message}`)),
      api<CommunicationLog[]>('/api/communications').then(setCommunicationLogs).catch(() => undefined),
    ]);
    setDataWarning(warnings.join(' | '));
  }

  function flash(message: string) {
    setNotice(message);
    setError('');
    window.setTimeout(() => setNotice(''), 5000);
  }

  function fail(reason: unknown) {
    setError(reason instanceof Error ? reason.message : 'Something went wrong.');
    setNotice('');
  }

  async function addLead() {
    if (!newLead.name.trim()) return;
    try {
      await api('/api/crm', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(newLead) });
      setNewLead({ name: '', company: '', email: '', notes: '', status: 'new' });
      setLeads(await api<Lead[]>('/api/crm'));
      flash('Lead added to the pipeline.');
    } catch (reason) { fail(reason); }
  }

  async function addProject() {
    if (!newProject.name.trim()) return;
    try {
      await api('/api/projects', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(newProject) });
      setNewProject({ name: '', description: '', executive: 'Heather', status: 'planning' });
      setProjects(await api<Project[]>('/api/projects'));
      flash('Project added.');
    } catch (reason) { fail(reason); }
  }

  async function addTask() {
    if (!newTask.title.trim()) return;
    try {
      await api('/api/tasks', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(newTask) });
      setNewTask({ title: '', assigned_to: '', priority: 'medium', status: 'open' });
      setTasks(await api<Task[]>('/api/tasks'));
      flash('Task added.');
    } catch (reason) { fail(reason); }
  }

  async function addKnowledge() {
    if (!newKnowledge.title.trim()) return;
    try {
      await api('/api/knowledge', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(newKnowledge) });
      setNewKnowledge({ title: '', category: '', content: '' });
      setKnowledge(await api<KnowledgeItem[]>('/api/knowledge'));
      flash('Document added to the Knowledge Vault.');
    } catch (reason) { fail(reason); }
  }

  async function addContact() {
    if (!newContact.name.trim() || !newContact.organization.trim()) return;
    try {
      await api('/api/contacts', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(newContact) });
      setNewContact({ name: '', organization: '', title: '', email: '', phone: '', city: '', state: 'NM', category: 'Other', notes: '', verification: 'research-lead' });
      const result = await api<ContactsResponse>('/api/contacts');
      setContacts(result.contacts);
      setContactSource(result.source);
      flash('Contact saved.');
    } catch (reason) { fail(reason); }
  }

  async function patchRecord(endpoint: string, record: Record<string, unknown>, success: string) {
    try {
      await api(endpoint, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(record) });
      await loadAll();
      flash(success);
    } catch (reason) { fail(reason); }
  }

  async function deleteRecord(endpoint: string, id: string, success: string) {
    try {
      await api(endpoint, { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id }) });
      await loadAll();
      flash(success);
    } catch (reason) { fail(reason); }
  }

  async function sendChat() {
    const message = chatInput.trim();
    if (!message || chatBusy) return;
    const next = [...messages, { role: 'user' as const, content: message }];
    setMessages(next);
    setChatInput('');
    setChatBusy(true);
    try {
      const result = await api<{ reply: string }>('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ executive, messages: next }),
      });
      setMessages([...next, { role: 'assistant', content: result.reply }]);
    } catch (reason) {
      setMessages([...next, { role: 'assistant', content: reason instanceof Error ? reason.message : 'The executive team could not respond.' }]);
    } finally {
      setChatBusy(false);
    }
  }

  async function buildPlan() {
    try {
      const result = await api<BuilderPlan>('/api/builder', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(builder),
      });
      setBuilderPlan(result);
      flash('Builder plan generated.');
    } catch (reason) { fail(reason); }
  }

  function chooseCommunicationContact(contactId: string, channel = communication.channel) {
    const contact = contacts.find((item) => item.id === contactId);
    setCommunication((current) => ({
      ...current,
      contactId,
      channel,
      to: channel === 'sms' ? contact?.phone || '' : contact?.email || '',
      subject: channel === 'sms' ? '' : current.subject,
    }));
  }

  function openCommunication(contact: Contact, channel: 'email' | 'sms') {
    setCommunication({
      contactId: contact.id,
      channel,
      to: channel === 'sms' ? contact.phone || '' : contact.email || '',
      subject: '',
      body: '',
      goal: '',
      executive: 'Heather',
    });
    setTab('Communications');
  }

  async function draftCommunication() {
    const contact = contacts.find((item) => item.id === communication.contactId);
    if (!communication.goal.trim()) {
      fail(new Error('Tell the executive what the message needs to accomplish.'));
      return;
    }
    setCommunicationBusy('draft');
    try {
      const result = await api<{ subject: string; body: string }>('/api/communications/draft', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          executive: communication.executive,
          channel: communication.channel,
          goal: communication.goal,
          recipientName: contact?.name || '',
          organization: contact?.organization || '',
          notes: contact?.notes || '',
        }),
      });
      setCommunication((current) => ({ ...current, subject: result.subject, body: result.body }));
      flash(`${communication.executive} prepared a draft for review.`);
    } catch (reason) { fail(reason); }
    finally { setCommunicationBusy(''); }
  }

  async function sendCommunication() {
    const contact = contacts.find((item) => item.id === communication.contactId);
    if (!communication.to.trim() || !communication.body.trim()) {
      fail(new Error('Recipient and message are required.'));
      return;
    }
    if (communication.channel === 'email' && !communication.subject.trim()) {
      fail(new Error('Email subject is required.'));
      return;
    }
    setCommunicationBusy('send');
    try {
      await api('/api/communications', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          channel: communication.channel,
          to: communication.to,
          subject: communication.subject,
          body: communication.body,
          recipientName: contact?.name || '',
        }),
      });
      setCommunicationLogs(await api<CommunicationLog[]>('/api/communications'));
      flash(`${communication.channel === 'email' ? 'Email' : 'Text message'} sent and logged.`);
    } catch (reason) { fail(reason); }
    finally { setCommunicationBusy(''); }
  }

  const contactCategories = useMemo(
    () => ['All', ...Array.from(new Set(contacts.map((contact) => contact.category))).sort()],
    [contacts],
  );

  const filteredContacts = useMemo(() => {
    const query = contactSearch.trim().toLowerCase();
    return contacts.filter((contact) => {
      const categoryMatch = contactCategory === 'All' || contact.category === contactCategory;
      const searchMatch = !query || [contact.name, contact.organization, contact.title, contact.email, contact.phone, contact.state, contact.notes]
        .filter(Boolean)
        .join(' ')
        .toLowerCase()
        .includes(query);
      return categoryMatch && searchMatch;
    });
  }, [contacts, contactCategory, contactSearch]);

  const selectedCommunicationContact = contacts.find((contact) => contact.id === communication.contactId);
  const ownerContact = contacts.find((contact) => contact.external_key === 'owner-jim-rusk');
  const openTasks = tasks.filter((task) => task.status !== 'done');
  const activeProjects = projects.filter((project) => !['complete', 'on-hold'].includes(project.status));
  const pipelineLeads = leads.filter((lead) => lead.status !== 'closed');
  const priorityTasks = [...openTasks].sort((a, b) => (a.priority === 'high' ? -1 : b.priority === 'high' ? 1 : 0)).slice(0, 5);

  const Badge = ({ value }: { value: string }) => (
    <span className="badge" style={{ color: statusColor(value), borderColor: `${statusColor(value)}66`, background: `${statusColor(value)}18` }}>
      {value}
    </span>
  );

  return (
    <div className="shell">
      <aside className="sidebar">
        <div className="brand">ARIDON</div>
        <div className="tag">Infrastructure + AI Command Center</div>

        <div className="privacy-note">Private command center · human approval required for outbound messages.</div>

        <nav className="nav" aria-label="Aridon modules">
          {tabs.map((item) => (
            <button key={item} onClick={() => setTab(item)} className={tab === item ? 'active' : ''}>{item}</button>
          ))}
        </nav>
        <div className="footer">v0.4 Command Center<br />Aridon / Iron Grid Electric &amp; Water</div>
        <button className="logout-button" onClick={async () => { await fetch('/api/auth/logout', { method: 'POST' }); window.location.href = '/login'; }}>Sign out</button>
      </aside>

      <main className="main">
        <header className="hero">
          <div>
            <h1 className="h1">{tab}</h1>
            <div className="sub">Move contacts, communications, projects, and executive decisions through one system.</div>
          </div>
          <span className="pill"><span className="online-dot" /> System online</span>
        </header>

        {notice && <div className="banner success">{notice}</div>}
        {error && <div className="banner error">{error}</div>}
        {dataWarning && <div className="banner warning">Some database modules are in setup mode. {dataWarning}</div>}

        {tab === 'Dashboard' && (
          <section className="grid">
            <div className="card span8 command-card">
              <div className="eyebrow">Founder command brief</div>
              <h2>Good evening, Jim.</h2>
              <p className="muted">Your public research directory is loaded. The next pressure points are open tasks, active projects, and outreach that needs a clean follow-up.</p>
              <div className="row wrap">
                <button className="btn" onClick={() => setTab('Communications')}>Open Communications</button>
                <button className="btn secondary" onClick={() => setTab('Contacts')}>Search Contacts</button>
                <button className="btn ghost" onClick={() => setTab('Executive Chat')}>Ask Heather</button>
              </div>
            </div>
            <div className="card span4">
              <div className="kpi">{contacts.length}</div>
              <div className="muted">Research and business contacts</div>
              <div className="mini-note">Source: {contactSource}</div>
            </div>
            <div className="card span3"><div className="kpi">{pipelineLeads.length}</div><div className="muted">Open CRM leads</div></div>
            <div className="card span3"><div className="kpi">{activeProjects.length}</div><div className="muted">Active projects</div></div>
            <div className="card span3"><div className="kpi">{openTasks.length}</div><div className="muted">Open tasks</div></div>
            <div className="card span3"><div className="kpi">{communicationLogs.filter((item) => item.status === 'sent').length}</div><div className="muted">Messages logged</div></div>

            <div className="card span7">
              <div className="section-title"><div><div className="eyebrow">Execution queue</div><h2>Today&apos;s priorities</h2></div><button className="text-button" onClick={() => setTab('Tasks')}>View tasks</button></div>
              <div className="list">
                {priorityTasks.map((task) => (
                  <div className="item item-row" key={task.id}>
                    <div><strong>{task.title}</strong><div className="item-meta">{task.assigned_to || 'Unassigned'} · {task.priority} priority</div></div>
                    <Badge value={task.status} />
                  </div>
                ))}
                {priorityTasks.length === 0 && <div className="empty">No open tasks. The runway is clear.</div>}
              </div>
            </div>

            <div className="card span5">
              <div className="eyebrow">Outreach radar</div>
              <h2>Directory mix</h2>
              <div className="metric-list">
                {contactCategories.filter((category) => category !== 'All').slice(0, 7).map((category) => (
                  <div key={category}><span>{category}</span><strong>{contacts.filter((contact) => contact.category === category).length}</strong></div>
                ))}
              </div>
            </div>

            <div className="card span12">
              <div className="section-title"><div><div className="eyebrow">Recent outreach</div><h2>Communication log</h2></div><button className="text-button" onClick={() => setTab('Communications')}>Compose</button></div>
              <div className="table-wrap">
                <table>
                  <thead><tr><th>Channel</th><th>Recipient</th><th>Subject</th><th>Status</th><th>Date</th></tr></thead>
                  <tbody>
                    {communicationLogs.slice(0, 8).map((entry) => (
                      <tr key={entry.id}><td>{entry.channel}</td><td>{entry.recipient_name || entry.recipient}</td><td>{entry.subject || entry.body.slice(0, 60)}</td><td><Badge value={entry.status} /></td><td>{new Date(entry.created_at).toLocaleDateString()}</td></tr>
                    ))}
                    {communicationLogs.length === 0 && <tr><td colSpan={5} className="empty">No outbound messages logged yet.</td></tr>}
                  </tbody>
                </table>
              </div>
            </div>
          </section>
        )}

        {tab === 'Executive Chat' && (
          <section className="grid">
            <div className="card span4">
              <div className="eyebrow">Seven seats at the table</div>
              <h2>Select an executive</h2>
              <div className="executive-picker">
                {executives.map((item) => (
                  <button key={item.id} onClick={() => setExecutive(item.name)} className={executive === item.name ? 'selected' : ''} style={{ '--exec-color': item.color } as CSSProperties}>
                    <div className="avatar-sm" style={{ background: `linear-gradient(135deg,${item.color}55,${item.color}18)` }}>
                      <span style={{ color: item.color }}>{item.icon}</span>
                      {item.avatar && <img src={item.avatar} alt="" onError={(event) => { event.currentTarget.style.display = 'none'; }} />}
                    </div>
                    <div><strong>{item.name}</strong><small>{item.abbr} · {item.role}</small></div>
                  </button>
                ))}
              </div>
            </div>
            <div className="card span8 chat-card">
              <div className="section-title"><div><div className="eyebrow">Private executive room</div><h2>{executive}</h2></div><Badge value={chatBusy ? 'thinking' : 'online'} /></div>
              <div className="chat">
                {messages.map((message, index) => <div key={`${message.role}-${index}`} className={`msg ${message.role === 'user' ? 'user' : 'ai'}`}>{message.content}</div>)}
              </div>
              <div className="composer-row">
                <textarea value={chatInput} onChange={(event) => setChatInput(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); void sendChat(); } }} placeholder={`Ask ${executive}...`} />
                <button className="btn" onClick={() => void sendChat()} disabled={chatBusy}>{chatBusy ? 'Thinking...' : 'Send'}</button>
              </div>
            </div>
          </section>
        )}

        {tab === 'Communications' && (
          <section className="grid">
            <div className="card span7">
              <div className="section-title"><div><div className="eyebrow">Review before release</div><h2>Executive Communications Center</h2></div><Badge value={communication.channel} /></div>

              <div className="form-grid two">
                <label>Contact
                  <select value={communication.contactId} onChange={(event) => chooseCommunicationContact(event.target.value)}>
                    <option value="">Choose a contact</option>
                    {contacts.map((contact) => <option key={contact.id} value={contact.id}>{contact.name} · {contact.organization}</option>)}
                  </select>
                </label>
                <label>Channel
                  <select value={communication.channel} onChange={(event) => chooseCommunicationContact(communication.contactId, event.target.value)}>
                    <option value="email">Email</option>
                    <option value="sms">Text message</option>
                  </select>
                </label>
              </div>

              <div className="form-grid two">
                <label>Drafting executive
                  <select value={communication.executive} onChange={(event) => setCommunication({ ...communication, executive: event.target.value })}>
                    {executives.map((item) => <option key={item.id} value={item.name}>{item.name} ({item.abbr})</option>)}
                  </select>
                </label>
                <label>{communication.channel === 'email' ? 'Email address' : 'Mobile number'}
                  <input value={communication.to} onChange={(event) => setCommunication({ ...communication, to: event.target.value })} placeholder={communication.channel === 'email' ? 'name@organization.gov' : '+15055551212'} />
                </label>
              </div>

              <label>What should this message accomplish?
                <textarea value={communication.goal} onChange={(event) => setCommunication({ ...communication, goal: event.target.value })} placeholder="Example: Request a 30-minute call about a paid AWG-1000 feasibility study and ask who owns the funding pathway." />
              </label>
              <button className="btn secondary full" onClick={() => void draftCommunication()} disabled={communicationBusy !== ''}>{communicationBusy === 'draft' ? 'Drafting...' : `Draft with ${communication.executive}`}</button>

              {communication.channel === 'email' && <label>Subject<input value={communication.subject} onChange={(event) => setCommunication({ ...communication, subject: event.target.value })} placeholder="Subject line" /></label>}
              <label>Message for final review
                <textarea className="message-editor" value={communication.body} onChange={(event) => setCommunication({ ...communication, body: event.target.value })} placeholder="The executive draft will appear here. You remain in control of the final wording and send button." />
              </label>

              <div className="send-review">
                <div><strong>Final checkpoint</strong><p>Recipient: {selectedCommunicationContact ? `${selectedCommunicationContact.name} at ${selectedCommunicationContact.organization}` : communication.to || 'Not selected'}</p></div>
                <button className="btn" onClick={() => void sendCommunication()} disabled={communicationBusy !== ''}>{communicationBusy === 'send' ? 'Sending...' : `Send ${communication.channel === 'email' ? 'Email' : 'Text'}`}</button>
              </div>
            </div>

            <div className="card span5">
              <div className="eyebrow">Quick destinations</div>
              <h2>Message Jim or a saved contact</h2>
              {ownerContact ? (
                <div className="owner-card">
                  <strong>{ownerContact.name}</strong>
                  <span>{ownerContact.organization}</span>
                  <div className="row wrap">
                    {ownerContact.email && <button className="btn secondary small" onClick={() => openCommunication(ownerContact, 'email')}>Email Jim</button>}
                    {ownerContact.phone && <button className="btn secondary small" onClick={() => openCommunication(ownerContact, 'sms')}>Text Jim</button>}
                  </div>
                </div>
              ) : (
                <div className="setup-note">Add ARIDON_OWNER_EMAIL and ARIDON_OWNER_PHONE in Vercel to enable the private “Message Jim” destination without publishing your details in GitHub.</div>
              )}

              <h3>Recent sends</h3>
              <div className="list compact">
                {communicationLogs.slice(0, 8).map((entry) => (
                  <div className="item" key={entry.id}><div className="item-row"><strong>{entry.recipient_name || entry.recipient}</strong><Badge value={entry.status} /></div><div className="item-meta">{entry.channel} · {new Date(entry.created_at).toLocaleString()}</div></div>
                ))}
                {communicationLogs.length === 0 && <div className="empty">Nothing sent yet.</div>}
              </div>
            </div>
          </section>
        )}

        {tab === 'Contacts' && (
          <section className="grid">
            <div className="card span9">
              <div className="section-title"><div><div className="eyebrow">Aridon relationship map</div><h2>Contacts directory <span className="count">{filteredContacts.length}</span></h2></div><Badge value={contactSource} /></div>
              <div className="toolbar">
                <input value={contactSearch} onChange={(event) => setContactSearch(event.target.value)} placeholder="Search name, organization, email, phone, state, or notes" />
                <select value={contactCategory} onChange={(event) => setContactCategory(event.target.value)}>{contactCategories.map((category) => <option key={category}>{category}</option>)}</select>
              </div>
              <div className="contact-grid">
                {filteredContacts.map((contact) => (
                  <article className="contact-card" key={contact.id}>
                    <div className="contact-head"><div><strong>{contact.name}</strong><span>{contact.title || contact.category}</span></div><Badge value={contact.verification} /></div>
                    <h3>{contact.organization}</h3>
                    <div className="contact-lines">
                      {contact.email && <a href={`mailto:${contact.email}`}>{contact.email}</a>}
                      {contact.phone && <a href={`tel:${contact.phone}`}>{contact.phone}</a>}
                      {(contact.city || contact.state) && <span>{[contact.city, contact.state].filter(Boolean).join(', ')}</span>}
                    </div>
                    {contact.notes && <p>{contact.notes}</p>}
                    <div className="contact-actions">
                      {contact.email && <button className="btn secondary small" onClick={() => openCommunication(contact, 'email')}>Email</button>}
                      {contact.phone && <button className="btn secondary small" onClick={() => openCommunication(contact, 'sms')}>Text</button>}
                      {contact.phone && <a className="btn ghost small" href={`tel:${contact.phone}`}>Call</a>}
                      {!contact.is_seed && <button className="text-button danger-text" onClick={() => void deleteRecord('/api/contacts', contact.id, 'Contact deleted.')}>Delete</button>}
                    </div>
                  </article>
                ))}
              </div>
            </div>
            <div className="card span3 sticky-card">
              <div className="eyebrow">Private additions</div>
              <h2>Add contact</h2>
              <label>Name *<input value={newContact.name} onChange={(event) => setNewContact({ ...newContact, name: event.target.value })} /></label>
              <label>Organization *<input value={newContact.organization} onChange={(event) => setNewContact({ ...newContact, organization: event.target.value })} /></label>
              <label>Title<input value={newContact.title} onChange={(event) => setNewContact({ ...newContact, title: event.target.value })} /></label>
              <label>Email<input value={newContact.email} onChange={(event) => setNewContact({ ...newContact, email: event.target.value })} /></label>
              <label>Phone<input value={newContact.phone} onChange={(event) => setNewContact({ ...newContact, phone: event.target.value })} /></label>
              <div className="form-grid two"><label>State<input value={newContact.state} onChange={(event) => setNewContact({ ...newContact, state: event.target.value })} /></label><label>Category<input value={newContact.category} onChange={(event) => setNewContact({ ...newContact, category: event.target.value })} /></label></div>
              <label>Notes<textarea value={newContact.notes} onChange={(event) => setNewContact({ ...newContact, notes: event.target.value })} /></label>
              <button className="btn full" onClick={() => void addContact()}>Save Contact</button>
            </div>
          </section>
        )}

        {tab === 'CRM' && (
          <section className="grid">
            <div className="card span8">
              <div className="section-title"><div><div className="eyebrow">Opportunity pipeline</div><h2>CRM Leads <span className="count">{leads.length}</span></h2></div></div>
              <div className="list">
                {leads.map((lead) => (
                  <div className="item item-row" key={lead.id}>
                    <div><strong>{lead.name}</strong><div className="item-meta">{[lead.company, lead.email].filter(Boolean).join(' · ')}</div>{lead.notes && <p>{lead.notes}</p>}</div>
                    <div className="record-actions"><Badge value={lead.status} /><button className="btn secondary small" onClick={() => void patchRecord('/api/crm', { ...lead, status: nextValue(lead.status, ['new', 'contacted', 'qualified', 'closed']) }, 'Lead advanced.')}>Advance</button><button className="text-button danger-text" onClick={() => void deleteRecord('/api/crm', lead.id, 'Lead deleted.')}>Delete</button></div>
                  </div>
                ))}
                {leads.length === 0 && <div className="empty">No leads yet.</div>}
              </div>
            </div>
            <div className="card span4 sticky-card">
              <h2>Add lead</h2>
              <label>Name *<input value={newLead.name} onChange={(event) => setNewLead({ ...newLead, name: event.target.value })} /></label>
              <label>Company<input value={newLead.company} onChange={(event) => setNewLead({ ...newLead, company: event.target.value })} /></label>
              <label>Email<input value={newLead.email} onChange={(event) => setNewLead({ ...newLead, email: event.target.value })} /></label>
              <label>Notes<textarea value={newLead.notes} onChange={(event) => setNewLead({ ...newLead, notes: event.target.value })} /></label>
              <button className="btn full" onClick={() => void addLead()}>Add Lead</button>
            </div>
          </section>
        )}

        {tab === 'Projects' && (
          <section className="grid">
            <div className="card span8">
              <div className="section-title"><div><div className="eyebrow">Delivery map</div><h2>Projects <span className="count">{projects.length}</span></h2></div></div>
              <div className="list">
                {projects.map((project) => (
                  <div className="item item-row" key={project.id}>
                    <div><strong>{project.name}</strong><div className="item-meta">Lead: {project.executive || 'Unassigned'}</div>{project.description && <p>{project.description}</p>}</div>
                    <div className="record-actions"><Badge value={project.status} /><button className="btn secondary small" onClick={() => void patchRecord('/api/projects', { ...project, status: nextValue(project.status, ['planning', 'active', 'on-hold', 'complete']) }, 'Project status updated.')}>Advance</button><button className="text-button danger-text" onClick={() => void deleteRecord('/api/projects', project.id, 'Project deleted.')}>Delete</button></div>
                  </div>
                ))}
                {projects.length === 0 && <div className="empty">No projects yet.</div>}
              </div>
            </div>
            <div className="card span4 sticky-card">
              <h2>Add project</h2>
              <label>Name *<input value={newProject.name} onChange={(event) => setNewProject({ ...newProject, name: event.target.value })} /></label>
              <label>Description<textarea value={newProject.description} onChange={(event) => setNewProject({ ...newProject, description: event.target.value })} /></label>
              <label>Executive lead<select value={newProject.executive} onChange={(event) => setNewProject({ ...newProject, executive: event.target.value })}>{executives.map((item) => <option key={item.id} value={item.name}>{item.name} ({item.abbr})</option>)}</select></label>
              <button className="btn full" onClick={() => void addProject()}>Add Project</button>
            </div>
          </section>
        )}

        {tab === 'Tasks' && (
          <section className="grid">
            <div className="card span8">
              <div className="section-title"><div><div className="eyebrow">Execution queue</div><h2>Tasks <span className="count">{tasks.length}</span></h2></div></div>
              <div className="list">
                {tasks.map((task) => (
                  <div className="item item-row" key={task.id}>
                    <div><strong>{task.title}</strong><div className="item-meta">{task.assigned_to || 'Unassigned'} · {task.priority} priority</div></div>
                    <div className="record-actions"><Badge value={task.status} /><button className="btn secondary small" onClick={() => void patchRecord('/api/tasks', { ...task, status: nextValue(task.status, ['open', 'in-progress', 'done']) }, 'Task advanced.')}>Advance</button><button className="text-button danger-text" onClick={() => void deleteRecord('/api/tasks', task.id, 'Task deleted.')}>Delete</button></div>
                  </div>
                ))}
                {tasks.length === 0 && <div className="empty">No tasks yet.</div>}
              </div>
            </div>
            <div className="card span4 sticky-card">
              <h2>Add task</h2>
              <label>Title *<input value={newTask.title} onChange={(event) => setNewTask({ ...newTask, title: event.target.value })} /></label>
              <label>Assigned to<input value={newTask.assigned_to} onChange={(event) => setNewTask({ ...newTask, assigned_to: event.target.value })} /></label>
              <label>Priority<select value={newTask.priority} onChange={(event) => setNewTask({ ...newTask, priority: event.target.value })}><option value="high">High</option><option value="medium">Medium</option><option value="low">Low</option></select></label>
              <button className="btn full" onClick={() => void addTask()}>Add Task</button>
            </div>
          </section>
        )}

        {tab === 'Knowledge Vault' && (
          <section className="grid">
            <div className="card span8">
              <div className="section-title"><div><div className="eyebrow">Institutional memory</div><h2>Knowledge Vault <span className="count">{knowledge.length}</span></h2></div></div>
              <div className="list">
                {knowledge.map((item) => (
                  <div className="item" key={item.id}><div className="item-row"><strong>{item.title}</strong><div className="record-actions">{item.category && <Badge value={item.category} />}<button className="text-button danger-text" onClick={() => void deleteRecord('/api/knowledge', item.id, 'Document deleted.')}>Delete</button></div></div>{item.content && <p>{item.content.slice(0, 500)}{item.content.length > 500 ? '...' : ''}</p>}</div>
                ))}
                {knowledge.length === 0 && <div className="empty">No documents yet.</div>}
              </div>
            </div>
            <div className="card span4 sticky-card">
              <h2>Add document</h2>
              <label>Title *<input value={newKnowledge.title} onChange={(event) => setNewKnowledge({ ...newKnowledge, title: event.target.value })} /></label>
              <label>Category<input value={newKnowledge.category} onChange={(event) => setNewKnowledge({ ...newKnowledge, category: event.target.value })} /></label>
              <label>Content<textarea className="message-editor" value={newKnowledge.content} onChange={(event) => setNewKnowledge({ ...newKnowledge, content: event.target.value })} /></label>
              <button className="btn full" onClick={() => void addKnowledge()}>Add to Vault</button>
            </div>
          </section>
        )}

        {tab === 'Builder Mode' && (
          <section className="grid">
            <div className="card span6">
              <div className="eyebrow">Plain-English configuration</div><h2>Business Builder</h2>
              <label>Company name<input value={builder.companyName} onChange={(event) => setBuilder({ ...builder, companyName: event.target.value })} /></label>
              <label>What do you build, sell, install, or operate?<textarea value={builder.services} onChange={(event) => setBuilder({ ...builder, services: event.target.value })} /></label>
              <label>Who do you serve?<textarea value={builder.customers} onChange={(event) => setBuilder({ ...builder, customers: event.target.value })} /></label>
              <button className="btn full" onClick={() => void buildPlan()}>Generate Setup</button>
            </div>
            <div className="card span6">
              <div className="eyebrow">Generated operating map</div><h2>Builder output</h2>
              {builderPlan ? <div><p>{builderPlan.setupSummary}</p><h3>Modules</h3><div className="chip-list">{builderPlan.firstModules.map((item) => <span key={item}>{item}</span>)}</div><h3>Next steps</h3><div className="list">{builderPlan.nextSteps.map((item, index) => <div className="item" key={item}><strong>{index + 1}.</strong> {item}</div>)}</div></div> : <div className="empty">Complete the builder form to generate the operating map.</div>}
            </div>
          </section>
        )}

        {tab === 'Executive Team' && (
          <section className="grid">
            {executives.map((item) => (
              <article className="card span4 executive-card" key={item.id} style={{ borderTopColor: item.color }}>
                <div className="exec"><div className="avatar-lg" style={{ background: `linear-gradient(135deg,${item.color}55,${item.color}18)` }}><span style={{ color: item.color }}>{item.icon}</span>{item.avatar && <img src={item.avatar} alt="" onError={(event) => { event.currentTarget.style.display = 'none'; }} />}</div><div><div className="title">{item.name} <span style={{ background: item.color }}>{item.abbr}</span></div><div className="muted">{item.role}</div></div></div>
                <p>{item.tagline}</p>
                <div className="expertise">{item.expertise.map((skill) => <span key={skill}><i style={{ background: item.color }} />{skill}</span>)}</div>
                <button className="btn secondary full" style={{ borderColor: item.color, color: item.color }} onClick={() => { setExecutive(item.name); setTab('Executive Chat'); }}>Talk to {item.name}</button>
              </article>
            ))}
          </section>
        )}
      </main>
    </div>
  );
}
