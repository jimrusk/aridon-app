-- Aridon v0.4 Command Center - Supabase Schema
-- Run in Supabase SQL Editor. Safe to re-run.

create extension if not exists pgcrypto;

create table if not exists leads (
  id uuid default gen_random_uuid() primary key,
  name text not null,
  company text,
  email text,
  notes text,
  status text default 'new',
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists projects (
  id uuid default gen_random_uuid() primary key,
  name text not null,
  description text,
  executive text,
  status text default 'planning',
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists tasks (
  id uuid default gen_random_uuid() primary key,
  title text not null,
  assigned_to text,
  priority text default 'medium',
  status text default 'open',
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists knowledge_vault (
  id uuid default gen_random_uuid() primary key,
  title text not null,
  category text,
  content text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists contacts (
  id uuid default gen_random_uuid() primary key,
  external_key text unique not null,
  name text not null,
  organization text not null,
  title text,
  email text,
  phone text,
  city text,
  state text,
  category text default 'Other',
  notes text,
  verification text default 'research-lead',
  source text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists communications (
  id uuid default gen_random_uuid() primary key,
  channel text not null,
  recipient_name text,
  recipient text not null,
  subject text,
  body text not null,
  status text not null,
  provider_id text,
  error text,
  created_at timestamptz default now()
);

create index if not exists contacts_organization_idx on contacts (organization);
create index if not exists contacts_category_idx on contacts (category);
create index if not exists communications_created_at_idx on communications (created_at desc);
create index if not exists tasks_status_priority_idx on tasks (status, priority);
