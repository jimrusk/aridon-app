export function requiredString(value: unknown, field: string, max = 5000): string {
  if (typeof value !== 'string' || !value.trim()) {
    throw new Error(`${field} is required.`);
  }
  return value.trim().slice(0, max);
}

export function optionalString(value: unknown, max = 5000): string | null {
  if (typeof value !== 'string') return null;
  const result = value.trim().slice(0, max);
  return result || null;
}
