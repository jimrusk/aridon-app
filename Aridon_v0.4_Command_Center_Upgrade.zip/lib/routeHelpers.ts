import { NextResponse } from 'next/server';

export function jsonError(message: string, status = 400) {
  return NextResponse.json({ error: message }, { status });
}

export function cleanText(value: unknown, maxLength = 5000) {
  return typeof value === 'string' ? value.trim().slice(0, maxLength) : '';
}

export function pickChanges(
  input: unknown,
  fields: readonly string[]
): Record<string, string | boolean> {
  if (!input || typeof input !== 'object') return {};
  const source = input as Record<string, unknown>;
  const result: Record<string, string | boolean> = {};
  for (const field of fields) {
    const value = source[field];
    if (typeof value === 'string') result[field] = value.trim().slice(0, 10000);
    if (typeof value === 'boolean') result[field] = value;
  }
  return result;
}

export function errorMessage(error: unknown) {
  return error instanceof Error ? error.message : 'Unexpected server error.';
}
