# Aridon Command Center v0.4

Aridon is a Vercel-ready AI executive operating system for infrastructure development, AWG-1000 pilot work, Iron Grid power integration, contacts, communications, CRM, projects, tasks, and institutional knowledge.

## Included

- Founder dashboard and execution queue
- Seven-executive AI chat
- Communications Center with executive drafting and human review
- Email delivery through Resend
- SMS delivery through Twilio
- Private owner contact loaded from environment variables
- Searchable Aridon research contacts directory
- CRM, projects, tasks, and Knowledge Vault
- Status advancement and delete controls
- Supabase audit log for outbound communications
- Mobile-responsive interface

## Deploy

1. Import this repository into Vercel.
2. Copy the variables from `.env.example` into Vercel Project Settings.
3. Run `supabase-schema.sql` in the Supabase SQL Editor.
4. Redeploy.

## Security

- Set `ARIDON_ACCESS_PASSWORD` and `ARIDON_SESSION_SECRET` before enabling live AI or outbound messaging.
- Never place service-role keys, OpenAI keys, Twilio tokens, Resend keys, personal phone numbers, or private relationship contacts in GitHub.
- `ARIDON_OWNER_EMAIL` and `ARIDON_OWNER_PHONE` are read server-side from Vercel.
- Every email or text requires a visible review step and an explicit send action.

## Contact data

The app ships with public or business-routing contacts documented in Aridon research packages. Staff assignments marked `reconfirm` should be checked before formal outreach. Private relationship contacts should be added through the Contacts screen after Supabase is configured, not committed to this public repository.
