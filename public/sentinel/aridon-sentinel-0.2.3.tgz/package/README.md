# Aridon Sentinel

A runtime authorization and detection layer for AI agents — and, as of v0.2.3,
a treasury firewall for value movement. Sentinel is designed for **detecting
agent and human hacking**: rogue or compromised AI agents and human attackers.
It intercepts actions **before execution**, scores malicious intent, gates
consequential actions behind per-action authorization and human approval,
authorizes treasury transactions against policy **before signature**, and
records every decision in a SHA-256 hash-chained, tamper-evident audit log.

> **HONEST-STAGE DISCLOSURES — read before integrating.**
>
> - This is **working code**, not a finished product. It is a development-stage
>   technical preview.
> - Test results below come from **synthetic internal scenarios only**: 13/13
>   hostile scenarios detected, 0/5 benign false positives, measured by the
>   package's own internal red-team harness — not by an independent party.
> - **No customers. No production deployments.**
> - **No independent penetration test** has been performed. The included
>   harness is white-box self-testing and is **not** a substitute for a
>   third-party penetration test (required for SOC 2, ISO 27001, IRAP, FedRAMP).
> - **No SOC 2, ISO 27001, IRAP, FedRAMP, or government certification.**
> - Sentinel provides **decision support, not a security guarantee**. A low
>   score is not proof an activity is safe or authorized. It does not replace
>   platform safety controls, legal review, or human approval for consequential
>   actions, and it has no offensive ("hack-back") capability.
> - The treasury firewall **does not prevent the initial compromise** of
>   keys, endpoints, or people. Its threat model is *assume breach*: it
>   contains the blast radius by refusing to authorize anomalous value
>   movement. Stolen keys alone are not enough to drain a guarded treasury —
>   but endpoint security, key management (HSM/MPC), and phishing resistance
>   remain the operator's responsibility.

## What's new in 0.2.3 — Treasury Firewall

The agent-action layer answers "should this actor do this thing?" The treasury
firewall answers "should **value move**?" It is initiator-agnostic — AI agent,
human operator, or automated system — because hot-wallet drains and signer
deception do not care who clicked. New module: `sentinelTreasury.ts`,
evaluated by `evaluateTreasuryTransaction(tx, policy, baseline)`:

- **What-you-sign verification (hard deny).** The approval UI commits
  `sha256(canonical(fields as approved))`; the firewall recomputes from the
  fields actually submitted for signing. Any mismatch — the Bybit pattern,
  where the screen showed one transfer and the signer authorized another —
  is denied before signature.
- **Hard policy limits (deny).** Per-transaction, hourly, and daily outflow
  caps. A Bitget-shape drain ($8M to a fresh address at 03:17 UTC) dies on
  the single-transaction limit alone.
- **Anomaly scoring (0–100).** Never-seen destination (+35), off-hours (+15),
  >5x baseline average (+25), hourly outflow above 80% of cap (+20). Score
  ≥ 50 denies; score ≥ the circuit-breaker threshold (default 80) returns
  `freeze` — the host system halts all outflows until human review.
- **Quorum enforcement.** Transfers at or above the quorum threshold need N
  distinct approvals; a single compromised or coerced signer cannot move
  quorum-scale funds alone.
- **New-address quarantine.** First-seen destinations are capped without
  human approval.
- Verdicts: `allow` | `human_approval` | `deny` | `freeze`. Every evaluation
  returns reasons, the anomaly score, and quorum status for the audit record.

What it is not: an on-chain transaction simulator (no RPC/node dependency —
intent is verified structurally), a key manager (keys stay in the operator's
HSM/MPC; the firewall never sees or holds them), or endpoint security.

## What's new in 0.2.1

- **Resource-exhaustion / anomalous-spend detection.** New signal categories
  in `analyzeSentinel`: `resource-exhaustion` (bulk provisioning or mass
  creation — e.g. "provision 50 VMs", "spin up 100 instances"),
  `approval-evasion` ("skip all approvals", "no approval needed"),
  `treasury-drain` ("entire treasury", "all funds", "drain the account"),
  and `urgency-pressure` (weak standalone signal). Mass provisioning at
  detected scale now counts as a consequential action: it is held for human
  approval at minimum, and denied when combined with evasion language.
- The shipped `examples/agiloop-gate.mjs` integration demonstrates the fix:
  the 50-VM provisioning attack that executed under v0.2.0 is now blocked
  before execution. All disclosures above still apply — this is synthetic
  self-testing, not independent validation.

## Install

```bash
npm install https://aridon-v02.vercel.app/sentinel/aridon-sentinel-0.2.3.tgz
```

Requires Node.js 18+. Zero runtime dependencies. (The package will also
publish to the npm registry as `@aridon/sentinel` once the scope is
registered there.)

## Quick start

```js
import { analyzeSentinel, SentinelAuditLog } from '@aridon/sentinel';

// Gate a proposed agent action BEFORE it executes.
const assessment = analyzeSentinel({
  prompt: userPrompt,
  history: recentTurns,               // optional, newest last
  requestedActions: [                 // human-readable descriptions of
    'send email to finance@…',        // proposed external actions
    'transfer payment of $50,000',
  ],
});

if (assessment.actionGate.mode === 'deny') {
  // Do not execute.
} else if (assessment.actionGate.mode === 'human_approval') {
  // Route to a human approver; record the decision in the audit log.
}

// assessment.disposition: 'allow' | 'restricted' | 'review' | 'block'
// assessment.score: 0–100, with reasons, matched signals, trajectory
// analysis (escalation / repeated evasion), and provider-signal consensus.
```

Tamper-evident audit trail:

```js
const log = new SentinelAuditLog();

log.append({
  tenantId: 'acme',
  actor: 'agent:planner-1',
  eventType: 'decision', // decision | approval | override | policy_change | incident | pentest_run | chain_verification
  summary: 'Blocked credential-theft prompt (score 80)',
  details: { assessment },
});

const check = log.verify(); // { ok: true, checked: 3, tipHash }
if (!check.ok) {
  // Chain was altered — check.brokenAtSeq identifies the entry.
}
```

Run the built-in red-team harness (12 synthetic scenarios: 9 hostile attack
categories + 3 benign false-positive controls):

```js
import { runSentinelPentest } from '@aridon/sentinel';

const report = runSentinelPentest();
// report.verdict: 'PASS' | 'FAIL'
// report.hostile: { total, caught, missed, detectionRate }
// report.benign:  { total, blocked, falsePositiveRate }
// Every run is itself written to the audit log.
```

## API overview

| Export | What it does |
|---|---|
| `analyzeSentinel(input)` | Scores a prompt + conversation trajectory + proposed actions; returns disposition, 0–100 score, reasons, signals, action gate (`pass` \| `human_approval` \| `deny`), trajectory analysis, provider consensus. |
| `SentinelAuditLog` | Append-only, SHA-256 hash-chained audit log. `append`, `verify`, `recordVerification`, `list`, `exportJson`. Also exported as the process-local singleton `sentinelAuditLog`. |
| `runSentinelPentest()` | Runs the 12-scenario synthetic adversarial corpus; returns a verdict, detection/false-positive rates, and per-scenario results. |
| `runSentinelBenchmark()` | Runs the transparent defensive benchmark corpus (context discrimination, trajectory awareness, action gating, provider-signal fusion). |
| `scoreSentinelIncident(signals)` | Scores a structured incident-signal set to a 0–100 risk score and severity. |
| `containmentPlan(signals)` | Generates containment actions for the observed signals. |
| `isAutomaticEscalationEligible(policy, …)` | Policy check for automatic escalation (default policy requires human approval). |
| `buildAuthorityReport(args)` | Formats a structured incident report for authorities. |

Authorized defensive work is preserved: pass `authorizationContext`
(e.g. `"Authorized penetration test on owned lab systems"`) and legitimate
security, incident-response, and administrative activity scores down while
safety checks stay active. Clearly harmful language is never waved through by
context alone.

## Design principles

- Detect **intent and behavioral trajectories**, not keywords alone.
- Require an **independent gate** before consequential tool actions.
- Escalate ambiguous consequential actions to **human review**.
- Preserve legitimate **authorized defensive** research.
- Keep raw prompts with the originating provider; share only **minimized
  threat indicators** across organizations.
- **Hash-chain every decision** so the audit trail cannot be quietly rewritten.

## Development

```bash
npm install
npm run build   # dual CJS + ESM output with .d.ts declarations → dist/
npm test        # builds, then runs examples/smoke.mjs against dist/
npm run pentest # runs the 12-scenario harness against the built package
```

## Examples

- `examples/smoke.mjs` — quick engine smoke test (run with `npm test`).
- `examples/agiloop-gate.mjs` — reference integration: a simulated
  Agiloop-style self-funded agent (USDC treasury, infra provisioning, paid
  API) with every consequential action gated by Sentinel before execution.
  Simulation only — no real chain, infra, or money.

```bash
node examples/agiloop-gate.mjs
```

## License

MIT — see [LICENSE](LICENSE).
