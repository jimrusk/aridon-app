# Aridon Sentinel

A runtime authorization and detection layer for AI agents — and, as of v0.2.3,
a treasury firewall for value movement, and as of v0.2.4, a crypto-agile
audit log ready for the post-quantum transition. Sentinel is designed for
**detecting agent and human hacking**: rogue or compromised AI agents and human attackers.
It intercepts actions **before execution**, scores malicious intent, gates
consequential actions behind per-action authorization and human approval,
authorizes treasury transactions against policy **before signature**, and
records every decision in a SHA-256 hash-chained, tamper-evident audit log.

> **PRODUCTION READINESS — the honest picture.**
>
> - This is **working software**, not a mockup. It screens real tool calls
>   before they execute, holds consequential actions for human approval, and
>   records every decision in a hash-chained audit log. Run
>   `npm run example:protected-agent` to watch it block a live
>   prompt-injection attack against real file and email tools.
> - Test results below come from **synthetic internal scenarios**: 18/18
>   hostile scenarios detected, 0 false positives on benign cases, measured by
>   the package's own internal red-team harness — not by an independent party.
> - **No independent penetration test** has been performed yet. The included
>   harness is white-box self-testing and is **not** a substitute for a
>   third-party penetration test (required for SOC 2, ISO 27001, IRAP, FedRAMP).
>   A pen-test quote is in hand; the test itself is the next milestone.
> - **No production customer deployments yet.** The library is ready to
>   integrate; live customer deployments are what comes next.
> - **No SOC 2, ISO 27001, IRAP, FedRAMP, or government certification.**
> - Sentinel provides **decision support, not a security guarantee**. A low
>   score is not proof an activity is safe or authorized. It does not replace
>   platform safety controls, legal review, or human approval for consequential
>   actions, and it has no offensive ("hack-back") capability.
> - The treasury firewall **does not prevent the initial compromise** of
>   keys, endpoints, or people. Its threat model is *assume breach*: it
>   contains the blast radius by refusing to authorize anomalous value
>   movement. Stolen keys alone are not enough to drain a guarded treasury —
>   but endpoint security, key management (HSM/MPC), and phishing resistance
>   remain the operator's responsibility.

## Protect your agent in 5 minutes

```js
import { SentinelGate, protectTool } from '@aridon/sentinel';

// 1. Create a gate for your deployment.
const gate = new SentinelGate({
  tenantId: 'acme-prod',
  onApproval: async (pending) => {
    // 2. Your human-approval path: Slack button, dashboard, PagerDuty…
    //    Return true to approve, false to deny.
    return await askHuman(pending);
  },
});

// 3. Wrap your real tools. Same signature, now screened before execution.
const safeSendEmail = protectTool('sendEmail', sendEmail, gate, {
  describe: (to, subject) => `send email to ${to} with subject "${subject}"`,
});
const safeWriteFile = protectTool('writeFile', writeFile, gate);

// 4. Use them like normal. Hostile calls throw SentinelDeniedError before
//    anything runs; consequential calls wait for your human; every decision
//    lands in gate.audit (hash-chained, verifiable).
await safeSendEmail('customer@acme.com', 'Invoice', pdfBytes);
```

No approval UI yet? Leave out `onApproval`: held actions throw
`SentinelApprovalRequiredError` with a pending id, and your app settles them
with `gate.approvePending(id, approver)` / `gate.denyPending(id, approver)`
then `gate.executeApproved(ticket, () => fn(...args))`.

## What's new in 0.4.0 — Host network sensor

The tool-call gate answers "should this agent do this thing?" The network
sensor answers "who is this machine actually talking to?" New module:
`sentinelNet.ts`, built around `NetMonitor`:

- **Wifi/ethernet flow visibility.** Polls the host connection table
  (`/proc/net/*` on Linux) and reports every remote IP/port, protocol, and
  connection state — plus per-interface byte counters from `/proc/net/dev`.
- **Allowlist / blocklist policy.** Private and link-local ranges are
  allowlisted by default; new external flows are flagged unless you allow
  them. Hostnames, exact IPs, and CIDRs all work.
- **Audit-joined.** Flagged flows append as `incident` entries to the
  hash-chained audit log, so network events sit in the same tamper-evident
  trail as tool-call decisions.
- **Honest limits.** Metadata only — no TLS payload inspection, no
  certificate interception. Linux only for now; short-lived flows can slip
  between polls. Monitor-only by default: it flags, it doesn't touch traffic.

## What's new in 0.7.1 — Pop-up never times out

Per Jim: no timeouts on the pop-up. The dialog stays open until a human
clicks Approve or Keep blocked — however long that takes. The
`popupTimeoutMs` option is gone.

## What's new in 0.7.0 — Pop-up approval by default

Jim's law: "most will not check the queue unless it is a pop-up screen." So
the queue is now the backstop, not the interface:

- Every firewall block pops a real desktop dialog — **Approve / Keep
  blocked** — showing who was stopped, where they were going, and why.
  Linux uses zenity, macOS uses a native dialog.
- No desktop (headless server, no dialog tool installed)? Nothing gets
  auto-decided — the request stays in `pendingApprovals()` until a human
  resolves it. Fail closed, never silent. The dialog itself never times out —
  it waits until clicked.
- `popup: false` disables the dialogs (pure queue mode). `popupApproval` and
  `PopupUnavailableError` are exported for custom wiring.

## What's new in 0.6.0 — Always-on enforcement + financial carve-out

Two changes Jim ordered:

- **Enforcement is now the default.** `enforce` defaults to `true` — the
  user opts out with `enforce: false`, not in. Without an `onApproval`
  resolver, flagged flows still block but wait in a manual queue instead of
  hanging forever: `pendingApprovals()` lists them, `resolveApproval(id,
  approved)` decides them. Enforcement degrades loudly, never silently.
- **Financial traffic is never stopped.** A built-in carve-out allowlists
  banks (Chase, BofA, Wells, Citi, Amex, Schwab, Fidelity…), email intake
  hosts (Gmail/Outlook/Yahoo IMAP+SMTP — where balance alerts arrive),
  fintech rails (Plaid, Stripe, PayPal), public DNS, and the machine's own
  `/etc/resolv.conf` nameservers. Hostnames are forward-resolved to IPs at
  startup and refreshed every 15 minutes (reverse-DNS alone would miss Gmail,
  whose IPs present as 1e100.net). Disable with `financialAllowlist: false`.

## What's new in 0.5.0 — Stop-until-approved enforcement

`NetMonitor` grows an opt-in `enforce` mode for the exact case Jim asked
about — an unknown, possibly encrypted sender:

- When a flow is flagged, its remote IP is **DROPped at the host firewall
  (iptables, INPUT + OUTPUT) before anything else happens** — encrypted or
  not, the packets stop.
- The block holds until your `onApproval` resolver returns true (human taps
  approve in chat, dashboard, wherever). Deny — or a resolver that throws —
  and the block stays: **fail closed**.
- Every rule is tagged `--comment sentinel-net`; `stop()` and process-exit
  hooks remove only Sentinel's own rules. `cleanup()` is idempotent.
- **Guardrails, not footguns:** `enforce: true` without an `onApproval`
  resolver throws at construction; without root it throws at `start()`
  rather than running half-enforced. `dryRun: true` logs the iptables
  commands instead of running them.

```js
const mon = new NetMonitor({
  tenantId: 'acme-prod',
  enforce: true, // needs root
  onApproval: async ({ flow, approve, deny }) => {
    const ok = await askHuman(flow); // your approval UI
    return ok; // true lifts the firewall block, false keeps it
  },
});
mon.start();
```

```js
import { NetMonitor } from '@aridon/sentinel';

const mon = new NetMonitor({
  tenantId: 'acme-prod',
  allowlist: ['api.openai.com', '10.0.0.0/8'],
  onSuspicious: (flow) => alertOps(flow), // your paging path
  auditLog, // optional: SentinelAuditLog instance
});
mon.start();
```

## What's new in 0.3.0 — Drop-in agent protection

The library could already score risk. Now it can **guard a working agent**:
`SentinelGate` + `protectTool()` wrap real tool functions so every call is
screened before execution, consequential calls wait for a human, approvals are
one-shot tickets (no replay), and the full decision trail is hash-chained.
`examples/protected-agent.mjs` proves it against real file and email tools,
including a live prompt-injection attack that gets blocked mid-run.

## What's new in 0.2.3 — Treasury Firewall

The agent-action layer answers "should this actor do this thing?" The treasury
firewall answers "should **value move**?" It is initiator-agnostic — AI agent,
human operator, or automated system — because hot-wallet drains and signer
deception do not care who clicked. New module: `sentinelTreasury.ts`,
evaluated by `evaluateTreasuryTransaction(tx, policy, baseline)`:

- **What-you-sign verification (hard deny).** The approval UI commits
  `sha256(canonical(fields as approved))`; the firewall recomputes from the
  fields actually submitted for signing. Any mismatch — the Bybit pattern,
  where the screen showed one transfer and the signer authorized another —
  is denied before signature.
- **Hard policy limits (deny).** Per-transaction, hourly, and daily outflow
  caps. A Bitget-shape drain ($8M to a fresh address at 03:17 UTC) dies on
  the single-transaction limit alone.
- **Anomaly scoring (0–100).** Never-seen destination (+35), off-hours (+15),
  >5x baseline average (+25), hourly outflow above 80% of cap (+20). Score
  ≥ 50 denies; score ≥ the circuit-breaker threshold (default 80) returns
  `freeze` — the host system halts all outflows until human review.
- **Quorum enforcement.** Transfers at or above the quorum threshold need N
  distinct approvals; a single compromised or coerced signer cannot move
  quorum-scale funds alone.
- **New-address quarantine.** First-seen destinations are capped without
  human approval.
- Verdicts: `allow` | `human_approval` | `deny` | `freeze`. Every evaluation
  returns reasons, the anomaly score, and quorum status for the audit record.

What it is not: an on-chain transaction simulator (no RPC/node dependency —
intent is verified structurally), a key manager (keys stay in the operator's
HSM/MPC; the firewall never sees or holds them), or endpoint security.

## What's new in 0.2.4 — Post-quantum readiness

A September 2026 *Cybersecurity Insider* briefing put the quantum threat
plainly: cybercriminals can steal encrypted data **today** and hold it until
quantum computers are powerful enough to crack it — "harvest now, decrypt
later." NIST agrees: it finalized the first post-quantum standards in
August 2024 — **FIPS 203 (ML-KEM)** for key encapsulation, **FIPS 204
(ML-DSA)** and **FIPS 205 (SLH-DSA)** for digital signatures — and its
transition guidance (NIST IR 8547) calls for quantum-vulnerable algorithms to
be deprecated by 2030 and disallowed by 2035.

What this means for Sentinel, stated precisely:

- **What quantum breaks:** RSA and elliptic-curve cryptography (Shor's
  algorithm). Any audit archive *encrypted* today with RSA/ECC key exchange
  is harvestable now and decryptable later. Operators should treat
  long-lived encrypted audit exports as already exposed unless they move to
  post-quantum or hybrid key exchange.
- **What quantum only weakens:** hashes and symmetric crypto (Grover's
  algorithm halves effective strength). SHA-256 keeps ~128-bit
  post-quantum security and remains NIST-approved — so Sentinel's
  hash-chained audit log is not the weak link.
- **What changed in the code:** the audit log is now **crypto-agile**.
  `new SentinelAuditLog({ hashAlgorithm: 'sha512' })` builds a chain on
  SHA-384 or SHA-512 instead of the SHA-256 default; the algorithm is
  recorded in export metadata so a chain is always verified with the
  algorithm it was built with. No format migration is needed when policy
  or regulation requires a stronger hash.
- **Roadmap, not a claim:** PQC-signed audit attestation (ML-DSA per
  FIPS 204) lands when Node.js / WebCrypto runtimes ship stable
  post-quantum signatures. Sentinel makes **no "quantum-proof" claim** —
  crypto-agility is preparation, not a guarantee, and the honest-stage
  disclosures above still apply in full.

## What's new in 0.2.1

- **Resource-exhaustion / anomalous-spend detection.** New signal categories
  in `analyzeSentinel`: `resource-exhaustion` (bulk provisioning or mass
  creation — e.g. "provision 50 VMs", "spin up 100 instances"),
  `approval-evasion` ("skip all approvals", "no approval needed"),
  `treasury-drain` ("entire treasury", "all funds", "drain the account"),
  and `urgency-pressure` (weak standalone signal). Mass provisioning at
  detected scale now counts as a consequential action: it is held for human
  approval at minimum, and denied when combined with evasion language.
- The shipped `examples/agiloop-gate.mjs` integration demonstrates the fix:
  the 50-VM provisioning attack that executed under v0.2.0 is now blocked
  before execution. All disclosures above still apply — this is synthetic
  self-testing, not independent validation.

## Install

```bash
npm install https://aridon-v02.vercel.app/sentinel/aridon-sentinel-0.2.4.tgz
```

Requires Node.js 18+. Zero runtime dependencies. (The package will also
publish to the npm registry as `@aridon/sentinel` once the scope is
registered there.)

## Quick start

```js
import { analyzeSentinel, SentinelAuditLog } from '@aridon/sentinel';

// Gate a proposed agent action BEFORE it executes.
const assessment = analyzeSentinel({
  prompt: userPrompt,
  history: recentTurns,               // optional, newest last
  requestedActions: [                 // human-readable descriptions of
    'send email to finance@…',        // proposed external actions
    'transfer payment of $50,000',
  ],
});

if (assessment.actionGate.mode === 'deny') {
  // Do not execute.
} else if (assessment.actionGate.mode === 'human_approval') {
  // Route to a human approver; record the decision in the audit log.
}

// assessment.disposition: 'allow' | 'restricted' | 'review' | 'block'
// assessment.score: 0–100, with reasons, matched signals, trajectory
// analysis (escalation / repeated evasion), and provider-signal consensus.
```

Tamper-evident audit trail:

```js
const log = new SentinelAuditLog();

log.append({
  tenantId: 'acme',
  actor: 'agent:planner-1',
  eventType: 'decision', // decision | approval | override | policy_change | incident | pentest_run | chain_verification
  summary: 'Blocked credential-theft prompt (score 80)',
  details: { assessment },
});

const check = log.verify(); // { ok: true, checked: 3, tipHash }
if (!check.ok) {
  // Chain was altered — check.brokenAtSeq identifies the entry.
}

// Post-quantum readiness: build the chain on SHA-384 or SHA-512 instead of
// the SHA-256 default. The algorithm is recorded in export metadata so the
// chain is always verified with the algorithm it was built with.
const hardenedLog = new SentinelAuditLog({ hashAlgorithm: 'sha512' });
```

Run the built-in red-team harness (12 synthetic scenarios: 9 hostile attack
categories + 3 benign false-positive controls):

```js
import { runSentinelPentest } from '@aridon/sentinel';

const report = runSentinelPentest();
// report.verdict: 'PASS' | 'FAIL'
// report.hostile: { total, caught, missed, detectionRate }
// report.benign:  { total, blocked, falsePositiveRate }
// Every run is itself written to the audit log.
```

## API overview

| Export | What it does |
|---|---|
| `analyzeSentinel(input)` | Scores a prompt + conversation trajectory + proposed actions; returns disposition, 0–100 score, reasons, signals, action gate (`pass` \| `human_approval` \| `deny`), trajectory analysis, provider consensus. |
| `SentinelAuditLog` | Append-only, crypto-agile hash-chained audit log (SHA-256 default; SHA-384/512 selectable). `append`, `verify`, `recordVerification`, `list`, `exportJson`. Also exported as the process-local singleton `sentinelAuditLog`. |
| `runSentinelPentest()` | Runs the 12-scenario synthetic adversarial corpus; returns a verdict, detection/false-positive rates, and per-scenario results. |
| `runSentinelBenchmark()` | Runs the transparent defensive benchmark corpus (context discrimination, trajectory awareness, action gating, provider-signal fusion). |
| `scoreSentinelIncident(signals)` | Scores a structured incident-signal set to a 0–100 risk score and severity. |
| `containmentPlan(signals)` | Generates containment actions for the observed signals. |
| `isAutomaticEscalationEligible(policy, …)` | Policy check for automatic escalation (default policy requires human approval). |
| `buildAuthorityReport(args)` | Formats a structured incident report for authorities. |

Authorized defensive work is preserved: pass `authorizationContext`
(e.g. `"Authorized penetration test on owned lab systems"`) and legitimate
security, incident-response, and administrative activity scores down while
safety checks stay active. Clearly harmful language is never waved through by
context alone.

## Design principles

- Detect **intent and behavioral trajectories**, not keywords alone.
- Require an **independent gate** before consequential tool actions.
- Escalate ambiguous consequential actions to **human review**.
- Preserve legitimate **authorized defensive** research.
- Keep raw prompts with the originating provider; share only **minimized
  threat indicators** across organizations.
- **Hash-chain every decision** so the audit trail cannot be quietly rewritten.

## Development

```bash
npm install
npm run build   # dual CJS + ESM output with .d.ts declarations → dist/
npm test        # builds, then runs examples/smoke.mjs against dist/
npm run pentest # runs the 12-scenario harness against the built package
```

## Examples

- `examples/smoke.mjs` — quick engine smoke test (run with `npm test`).
- `examples/agiloop-gate.mjs` — reference integration: a simulated
  Agiloop-style self-funded agent (USDC treasury, infra provisioning, paid
  API) with every consequential action gated by Sentinel before execution.
  Simulation only — no real chain, infra, or money.

```bash
node examples/agiloop-gate.mjs
```

## License

MIT — see [LICENSE](LICENSE).
